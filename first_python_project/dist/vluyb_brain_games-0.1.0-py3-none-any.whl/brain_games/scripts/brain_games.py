#!/usr/bin/env/ python3
def greet():
        print('Wellcome to the Brain Games!')
def main():
        greet()
if __name__ == '__main__':
        main()
